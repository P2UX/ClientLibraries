//
//  P2UXBasicDataAuth.h
//  P2UXCore
//
//  Created by Steve Ansell on 1/2/15.
//  Copyright (c) 2015 Phase 2 Industries, LLC. All rights reserved.
//

#import "P2UXDataAuthSubclass.h"

@interface P2UXBasicDataAuth : P2UXDataAuth

@end
