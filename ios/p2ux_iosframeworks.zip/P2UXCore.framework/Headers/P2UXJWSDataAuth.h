//
//  P2UXJWTDataAuth.h
//  P2UXCore
//
//  Created by Steve Ansell on 1/28/15.
//  Copyright (c) 2015 Phase 2 Industries, LLC. All rights reserved.
//

#import <P2UXCore/P2UXOAuthDataAuthSubclass.h>
#import <P2UXCore/NSData+P2UX.h>

@interface P2UXJWSDataAuth : P2UXOAuthDataAuth
@end
