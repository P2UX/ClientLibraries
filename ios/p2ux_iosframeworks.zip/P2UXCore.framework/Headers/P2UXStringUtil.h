//
//  P2UXStringUtil.h
//  P2UXCore
//
//  Created by Stephen Schalkhauser on 11/12/12.
//
//

#import <Foundation/Foundation.h>

@interface P2UXStringUtil : NSObject
+(BOOL) containsString:(NSString*)string substring:(NSString*)substring;
@end
