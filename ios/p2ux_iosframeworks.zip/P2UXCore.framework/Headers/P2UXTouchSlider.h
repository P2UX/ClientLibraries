//
//  P2UXTouchSlider.h
//  P2UXCore
//
//  Created by Stephen Schalkhauser on 8/21/16.
//  Copyright © 2016 Phase 2 Industries, LLC. All rights reserved.
//

#import <P2UXCore/P2UXCore.h>

@interface P2UXTouchSlider : P2UXProgress

@end
