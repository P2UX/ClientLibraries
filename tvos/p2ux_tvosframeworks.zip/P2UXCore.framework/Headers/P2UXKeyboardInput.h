//
//  P2UXKeyboardInput.h
//  P2UXCore
//
//  Created by Stephen Schalkhauser on 11/11/14.
//  Copyright (c) 2014 Phase 2 Industries, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface P2UXKeyboardInput : UITextField

@end
