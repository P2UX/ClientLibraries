//
//  P2UXStaticDataSource.h
//  P2UXCore
//
//  Created by Steve Ansell on 6/16/14.
//  Copyright (c) 2014 Phase 2 Industries, LLC. All rights reserved.
//

#import "P2UXDataSourceSubclass.h"

@interface P2UXStaticDataSource : P2UXDataSource

@end
